package com.quickex.mapper.doc;

import com.quickex.domain.doc.KoUserCulturalHeritageDoc;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoUserCulturalHeritageDocMapper extends BaseMapper<KoUserCulturalHeritageDoc> {

}
