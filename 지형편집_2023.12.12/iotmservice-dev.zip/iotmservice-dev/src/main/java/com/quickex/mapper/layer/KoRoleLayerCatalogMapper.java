package com.quickex.mapper.layer;

import com.quickex.domain.layer.KoRoleLayerCatalog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface KoRoleLayerCatalogMapper extends BaseMapper<KoRoleLayerCatalog> {

}
