package com.quickex.service.layer;

import com.quickex.core.service.IBaseService;
import com.quickex.domain.layer.KoUserLayerCollection;
import com.baomidou.mybatisplus.extension.service.IService;


public interface IKoUserLayerCollectionService extends IBaseService<KoUserLayerCollection> {

}
