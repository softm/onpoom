package com.quickex.domain.systable.RequestDto;

public class TableUserAuthorityDetailEntity {

}
