package com.quickex.mapper.user;

import com.quickex.domain.user.KoServiceCollectionType;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoServiceCollectionTypeMapper extends BaseMapper<KoServiceCollectionType> {

}
