package com.quickex.mapper.layer;

import com.quickex.domain.layer.KoAgentConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoAgentConfigMapper extends BaseMapper<KoAgentConfig> {

}
