package com.quickex.service.user;

import com.quickex.core.service.IBaseService;
import com.quickex.domain.user.KoUserMenu;
import com.baomidou.mybatisplus.extension.service.IService;


public interface IKoUserMenuService extends IBaseService<KoUserMenu> {

}
