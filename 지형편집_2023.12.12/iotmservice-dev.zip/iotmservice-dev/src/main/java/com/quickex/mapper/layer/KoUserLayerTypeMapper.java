package com.quickex.mapper.layer;

import com.quickex.domain.layer.KoUserLayerType;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoUserLayerTypeMapper extends BaseMapper<KoUserLayerType> {

}
