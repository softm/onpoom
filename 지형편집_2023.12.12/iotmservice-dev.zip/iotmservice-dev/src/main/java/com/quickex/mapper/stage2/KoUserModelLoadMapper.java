package com.quickex.mapper.stage2;

import com.quickex.domain.stage2.KoUserModelLoad;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface KoUserModelLoadMapper extends BaseMapper<KoUserModelLoad> {

}
