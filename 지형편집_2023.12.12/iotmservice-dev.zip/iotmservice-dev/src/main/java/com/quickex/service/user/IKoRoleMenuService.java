package com.quickex.service.user;

import com.quickex.core.service.IBaseService;
import com.quickex.domain.user.KoRoleMenu;
import com.baomidou.mybatisplus.extension.service.IService;


public interface IKoRoleMenuService extends IBaseService<KoRoleMenu> {

}
