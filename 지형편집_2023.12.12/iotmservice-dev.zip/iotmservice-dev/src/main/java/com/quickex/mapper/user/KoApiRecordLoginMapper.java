package com.quickex.mapper.user;

import com.quickex.domain.user.KoApiRecordLogin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoApiRecordLoginMapper extends BaseMapper<KoApiRecordLogin> {

}
