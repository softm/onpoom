package com.quickex.mapper.stage2;

import com.quickex.domain.stage2.KoTerrainModel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoTerrainModelMapper extends BaseMapper<KoTerrainModel> {

}
