package com.quickex.mapper.layer;

import com.quickex.domain.layer.KoMapConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoMapConfigMapper extends BaseMapper<KoMapConfig> {

}
