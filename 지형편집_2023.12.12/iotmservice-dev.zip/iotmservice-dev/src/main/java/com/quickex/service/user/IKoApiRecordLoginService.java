package com.quickex.service.user;

import com.quickex.core.service.IBaseService;
import com.quickex.domain.user.KoApiRecordLogin;
import com.baomidou.mybatisplus.extension.service.IService;


public interface IKoApiRecordLoginService extends IBaseService<KoApiRecordLogin> {

}
