package com.quickex.service.mapfile;

import com.quickex.core.service.IBaseService;
import com.quickex.domain.mapfile.KoMapFileCollection;
import com.baomidou.mybatisplus.extension.service.IService;


public interface IKoMapFileCollectionService extends IBaseService<KoMapFileCollection> {

}
