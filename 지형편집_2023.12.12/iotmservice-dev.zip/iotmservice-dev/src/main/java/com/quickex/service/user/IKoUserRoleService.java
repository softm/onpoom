package com.quickex.service.user;

import com.quickex.core.service.IBaseService;
import com.quickex.domain.user.KoUserRole;


public interface IKoUserRoleService extends IBaseService<KoUserRole> {

}
