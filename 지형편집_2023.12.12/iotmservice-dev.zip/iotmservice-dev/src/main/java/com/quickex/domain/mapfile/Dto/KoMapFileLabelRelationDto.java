package com.quickex.domain.mapfile.Dto;

import lombok.Data;

@Data
public class KoMapFileLabelRelationDto {

    public String id;

    public String fileId;

    public String name;

    public Boolean isCheck;

}
