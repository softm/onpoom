package com.quickex.mapper.user;

import com.quickex.domain.user.KoRoleMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoRoleMenuMapper extends BaseMapper<KoRoleMenu> {

}
