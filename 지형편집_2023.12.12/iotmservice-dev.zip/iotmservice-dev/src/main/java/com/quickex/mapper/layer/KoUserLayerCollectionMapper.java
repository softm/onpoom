package com.quickex.mapper.layer;

import com.quickex.domain.layer.KoUserLayerCollection;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoUserLayerCollectionMapper extends BaseMapper<KoUserLayerCollection> {

}
