package com.quickex.service.layer;
//
//import com.quickex.core.result.R;
////import org.opengis.referencing.FactoryException;
////import org.opengis.referencing.operation.TransformException;
//import org.springframework.web.multipart.MultipartFile;
//
//import java.io.IOException;
//
public interface IUpLoadService {
//
////    R upLoadZip(MultipartFile file) throws IOException, FactoryException, TransformException;
////
////    AjaxResult readShp( ) throws IOException;
}
