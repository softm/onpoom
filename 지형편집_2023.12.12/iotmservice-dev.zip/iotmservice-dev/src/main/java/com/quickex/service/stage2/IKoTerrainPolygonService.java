package com.quickex.service.stage2;

import com.quickex.core.service.IBaseService;
import com.quickex.domain.stage2.KoTerrainPolygon;
import com.baomidou.mybatisplus.extension.service.IService;


public interface IKoTerrainPolygonService extends IBaseService<KoTerrainPolygon> {

}
