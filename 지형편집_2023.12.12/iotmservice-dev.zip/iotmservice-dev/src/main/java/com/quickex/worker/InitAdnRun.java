package com.quickex.worker;


import com.quickex.core.util.spring.SpringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * init
 */
@Slf4j
@Component
public class InitAdnRun {

//    @PostConstruct
//    public void run() {
//        log.info("=========================== init ===========================");
//
//        //service.deleteLoginLog();
//
//
//    }

}
