package com.quickex.mapper.layer;

import com.quickex.domain.layer.KoMetaData;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoMetaDataMapper extends BaseMapper<KoMetaData> {

}
