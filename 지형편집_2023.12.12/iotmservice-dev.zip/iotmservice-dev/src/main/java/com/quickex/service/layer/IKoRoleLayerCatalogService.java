package com.quickex.service.layer;

import com.quickex.core.service.IBaseService;
import com.quickex.domain.layer.KoRoleLayerCatalog;
import com.baomidou.mybatisplus.extension.service.IService;


public interface IKoRoleLayerCatalogService extends IBaseService<KoRoleLayerCatalog> {

}
