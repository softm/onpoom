package com.quickex.mapper.stage2;

import com.quickex.domain.stage2.KoTerrainPolygon;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoTerrainPolygonMapper extends BaseMapper<KoTerrainPolygon> {

}
