package com.quickex.service.layer;

import com.quickex.core.service.IBaseService;
import com.quickex.domain.layer.KoUserLayerType;
import com.baomidou.mybatisplus.extension.service.IService;


public interface IKoUserLayerTypeService extends IBaseService<KoUserLayerType> {

}
