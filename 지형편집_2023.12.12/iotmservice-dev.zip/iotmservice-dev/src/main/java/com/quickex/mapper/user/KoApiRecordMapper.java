package com.quickex.mapper.user;

import com.quickex.domain.user.KoApiRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoApiRecordMapper extends BaseMapper<KoApiRecord> {

}
