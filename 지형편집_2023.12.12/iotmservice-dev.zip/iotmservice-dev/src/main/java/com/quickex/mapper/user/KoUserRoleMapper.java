package com.quickex.mapper.user;

import com.quickex.domain.user.KoUserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoUserRoleMapper extends BaseMapper<KoUserRole> {

}
