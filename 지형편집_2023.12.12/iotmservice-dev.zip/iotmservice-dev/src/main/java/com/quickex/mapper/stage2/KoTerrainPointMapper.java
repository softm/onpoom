package com.quickex.mapper.stage2;

import com.quickex.domain.stage2.KoTerrainPoint;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoTerrainPointMapper extends BaseMapper<KoTerrainPoint> {

}
