package com.quickex.mapper.stage2;

import com.quickex.domain.stage2.KoTerrainTid;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoTerrainTidMapper extends BaseMapper<KoTerrainTid> {

}
