package com.quickex.service.user;

import com.quickex.core.service.IBaseService;
import com.quickex.domain.user.KoMenuSort;
import com.baomidou.mybatisplus.extension.service.IService;


public interface IKoMenuSortService extends IBaseService<KoMenuSort> {

}
