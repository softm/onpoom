package com.quickex.mapper.layer;

import com.quickex.domain.layer.KoUserLayerCatalog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoUserLayerCatalogMapper extends BaseMapper<KoUserLayerCatalog> {

}
