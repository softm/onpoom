package com.quickex.service.layer;

import com.quickex.core.service.IBaseService;
import com.quickex.domain.layer.KoUserLayerCatalog;
import com.baomidou.mybatisplus.extension.service.IService;


public interface IKoUserLayerCatalogService extends IBaseService<KoUserLayerCatalog> {

}
