package com.quickex.core.enums;

/**
 * DataSource
 * 
 * @author ffzh
 */
public enum DataSourceType
{
    /**
     * MASTER
     */
    MASTER,

    /**
     * SLAVE
     */
    SLAVE
}
