package com.quickex.core.enums;

/**
 * Operation status
 * 
 * @author ffzh
 *
 */
public enum BusinessStatus
{
    /**
     * SUCCESS
     */
    SUCCESS,

    /**
     * FAIL
     */
    FAIL,
}
