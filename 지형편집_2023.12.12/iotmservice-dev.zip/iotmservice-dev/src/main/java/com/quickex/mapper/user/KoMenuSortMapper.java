package com.quickex.mapper.user;

import com.quickex.domain.user.KoMenuSort;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoMenuSortMapper extends BaseMapper<KoMenuSort> {

}
