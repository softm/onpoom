package com.quickex.mapper.stage2;

import com.quickex.domain.stage2.KoTextureLibraryData;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoTextureLibraryDataMapper extends BaseMapper<KoTextureLibraryData> {

}
