package com.quickex.mapper.doc;

import com.quickex.domain.doc.KoUserCulturalHeritagePdf;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoUserCulturalHeritagePdfMapper extends BaseMapper<KoUserCulturalHeritagePdf> {

}
