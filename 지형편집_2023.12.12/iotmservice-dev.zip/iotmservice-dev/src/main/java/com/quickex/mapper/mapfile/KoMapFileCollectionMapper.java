package com.quickex.mapper.mapfile;

import com.quickex.domain.mapfile.KoMapFileCollection;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface KoMapFileCollectionMapper extends BaseMapper<KoMapFileCollection> {

}
