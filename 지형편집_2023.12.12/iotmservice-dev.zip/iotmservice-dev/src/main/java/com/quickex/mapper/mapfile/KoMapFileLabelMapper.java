package com.quickex.mapper.mapfile;

import com.quickex.domain.mapfile.KoMapFileLabel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoMapFileLabelMapper extends BaseMapper<KoMapFileLabel> {

}
