package com.quickex.mapper.stage2;

import com.quickex.domain.stage2.KoTerrainTask;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoTerrainTaskMapper extends BaseMapper<KoTerrainTask> {

}
