package com.quickex.core.exception;

/**
 * Presentation mode exception
 * 
 * @author ffzh
 */
public class DemoModeException extends RuntimeException
{
    private static final long serialVersionUID = 1L;

    public DemoModeException()
    {
    }
}
