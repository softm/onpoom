package com.quickex.mapper.stage2;

import com.quickex.domain.stage2.KoUserModelLoadType;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoUserModelLoadTypeMapper extends BaseMapper<KoUserModelLoadType> {

}
