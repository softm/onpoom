package com.quickex.mapper.stage2;

import com.quickex.domain.stage2.KoTerrainBid;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoTerrainBidMapper extends BaseMapper<KoTerrainBid> {

}
