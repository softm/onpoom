package com.quickex.mapper.doc;

import com.quickex.domain.doc.KoUserCulturalHeritageShp;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoUserCulturalHeritageShpMapper extends BaseMapper<KoUserCulturalHeritageShp> {

}
