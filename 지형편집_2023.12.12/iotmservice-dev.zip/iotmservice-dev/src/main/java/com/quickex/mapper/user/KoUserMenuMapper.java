package com.quickex.mapper.user;

import com.quickex.domain.user.KoUserMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface KoUserMenuMapper extends BaseMapper<KoUserMenu> {

}
